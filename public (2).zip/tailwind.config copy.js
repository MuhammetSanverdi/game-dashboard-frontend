// tailwind.config.js
const flowbite = require("flowbite-react/tailwind");
/** @type {import('tailwindcss').Config} */
 
module.exports = {
  content: ["./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",    
    flowbite.content()
  ],    
 darkMode: 'class',
 theme: {
   extend: {
     colors: {
       palette:{"1":"#5356FF","2":"#378CE7","3":"#67C6E3","4":"#DFF5FF","5":"#67C6E3","6":"#DFF5FF","7":"#e5f8f8"},
       primary: {"50":"#eff6ff","100":"#dbeafe","200":"#bfdbfe","300":"#93c5fd","400":"#60a5fa","500":"#3b82f6","600":"#2563eb","700":"#1d4ed8","800":"#1e40af","900":"#1e3a8a","950":"#172554"}
     }
   },
   fontFamily: {
     'body': [
   'Inter',
   'ui-sans-serif',
   'system-ui',
   '-apple-system',
   'system-ui',
   'Segoe UI',
   'Roboto',
   'Helvetica Neue',
   'Arial',
   'Noto Sans',
   'sans-serif',
   'Apple Color Emoji',
   'Segoe UI Emoji',
   'Segoe UI Symbol',
   'Noto Color Emoji'
 ],
     'sans': [
   'Inter',
   'ui-sans-serif',
   'system-ui',
   '-apple-system',
   'system-ui',
   'Segoe UI',
   'Roboto',
   'Helvetica Neue',
   'Arial',
   'Noto Sans',
   'sans-serif',
   'Apple Color Emoji',
   'Segoe UI Emoji',
   'Segoe UI Symbol',
   'Noto Color Emoji'
 ]
   }
 },
 plugins: [
  flowbite.plugin(),
 ]

};
