import { useEffect, useState } from 'react'
import './App.css'
import Login from './pages/Login'
import { Navigate, Route, Routes } from 'react-router-dom'
import Register from './pages/Register'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';
import { PacmanLoader } from 'react-spinners'
import Spinner from './pages/Spinner'


function App() {
  const [count, setCount] = useState(0)
  const [isAuthenticated, setAuthenticated] = useState(null);
  const [isLoading,setIsLoading] = useState(false)


  useEffect(() => {
    const checkAuthenticated = async () => {
      const token = sessionStorage.getItem('Token');
      const expiration = sessionStorage.getItem('Expiration');
      
      if (token != null && new Date(expiration) > new Date()) {
        setAuthenticated(true);
      } else {
        setAuthenticated(false);
      }
    };

    checkAuthenticated();
  }, []);

  if (isAuthenticated === null) {
    return <></>
  }

  if (!isAuthenticated) {
    console.log(isLoading);
    
    return (
      <>
        <Routes>
          <Route path='/login' element={<Login setIsLoading={setIsLoading} />} />
          <Route path='/register' element={<Register setIsLoading={setIsLoading} />} />
          <Route path='/*' element={<Navigate to='/login' />} />
        </Routes>
        <Spinner isLoading={isLoading} />
        <ToastContainer
        position="bottom-right"
        limit={5}
        hideProgressBar={false}
        newestOnTop={false}
        rtl={false}
        theme="light"/>
      </>
    );
  } else {
    return (
      <>
       <Spinner loading={isLoading} />
        <ToastContainer />
      </>
    );
  }

  
}

export default App
