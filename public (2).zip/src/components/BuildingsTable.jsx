import React, { useEffect, useState } from 'react'
// import { Modal, ModalBody, ModalHeader } from "flowbite-react";
import { Button, Checkbox, Datepicker, Label, Modal, Textarea, TextInput } from "flowbite-react";
import ToastService from '../services/ToastService';
import { format } from 'date-fns';
import { Navigate, useNavigate } from 'react-router-dom';
const BuildingTable = () => {

    const navigate = useNavigate();
    const [status, setStatus] = useState(0);
    const [data, setData] = useState(null);
    const [openAddModal, setOpenAddModal] = useState(false);
    const [openUpdateModal, setOpenUpdateModal] = useState(false);
    const [openDeleteModal, setOpenDeleteModal] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);

    const [addSelectedCertificate, setAddSelectedCertificate] = useState({
        name: '',
        certificateDate: '',
        description: '',
        achievementStatus: false
    })

    const [updateSelectedCertificate, setUpdateSelectedCertificate] = useState({
        id: 0,
        name: '',
        certificateDate: '',
        description: '',
        achievementStatus: ''
    })

    const addModalCloseEvent = () => {
        setOpenAddModal(false);
        setAddSelectedCertificate({
            name: '',
            certificateDate: '',
            description: '',
            achievementStatus: false
        })

    }
    const updateModalCloseEvent = () => {
        setOpenUpdateModal(false);
        setUpdateSelectedCertificate({
            id: 0,
            name: '',
            certificateDate: '',
            description: '',
            achievementStatus: ''
        })

    }
   

    useEffect(() => {

        const response = async () => {
            try {
                const res = await CertificateService.getAll();
                setData(res.data.data);
                setStatus(res.status);
            }
            catch (error) {
                console.log(error);
            }
            finally {

                console.log(data, isLoaded);
            }
        }
        response();

    }, [])


    const selectedAddValueChange = (e, isDate = false) => {
        console.log(isDate);

        if (isDate) {
            const date = new Date(e).toLocaleDateString();
            setAddSelectedCertificate(prevState => ({
                ...prevState,
                certificateDate: date

            }));
        }
        else {
            const { id, value, type, checked } = e.target;
            console.log(id, value, type, checked);
            setAddSelectedCertificate(prevState => ({
                ...prevState,
                [id]: type === 'checkbox' ? checked : value


            }));
        }
    };
    const selectedUpdateValueChange = (e, isDate = false) => {

        if (isDate) {
            const date = new Date(e).toLocaleDateString();
            setUpdateSelectedCertificate(prevState => ({
                ...prevState,
                certificateDate: date

            }));
        }
        else {
            const { id, value, type, checked } = e.target;
            setUpdateSelectedCertificate(prevState => ({
                ...prevState,
                [id]: type === 'checkbox' ? checked : value


            }));
        }
    };

    const addButtonEvent = () => {

        // selectedData.certificateDate.slic
        const formattedDate = new Date().toLocaleDateString();
        console.log(formattedDate);
        setAddSelectedCertificate(prev => ({ ...prev, certificateDate: formattedDate }));
        setOpenAddModal(true);
    }

    const updateButtonEvent = async (id) => {
        console.log(id);
        let selectedData = await data.find(c => c.id === id);
        console.log(selectedData.certificateDate);

        const date = selectedData.certificateDate;
        selectedData.certificateDate = new Date(date).toLocaleDateString();

        console.log(selectedData);
        setOpenUpdateModal(true);
        // selectedData.certificateDate.slic
        setUpdateSelectedCertificate(selectedData);
    }

    const deleteButtonEvent = (id) => {
        const selectedData = data.find(c => c.id === id);
        setOpenDeleteModal(true);
        console.log(selectedData);
        setUpdateSelectedCertificate(selectedData);
    }


    const handleAddSubmit = async (e) => {
        e.preventDefault();
        // await setAddSelectedCertificate(prev=>({...prev,certificateDate:addSelectedCertificate.certificateDate.slice('.').reverse().join('-')} ))
        const splitedDate = addSelectedCertificate.certificateDate.split(/[./-]/);

        const requestBody = {
            name: addSelectedCertificate.name,
            certificateDate: `${splitedDate[2]}-${splitedDate[1]}-${splitedDate[0]}`,
            description: addSelectedCertificate.description,
            achievementStatus: addSelectedCertificate.achievementStatus
        }
        const response = await CertificateService.create(JSON.stringify(requestBody));
        console.log(response);
        if (response.status===200) {                      
            addModalCloseEvent(false)
            setTimeout(()=>{
                window.location.reload();
            },1000)            
        }    
    }


    const handleUpdateSubmit = async (e) => {
        e.preventDefault();
        const splitedDate = updateSelectedCertificate.certificateDate.split(/[./-]/);

        const requestBody = {
            id:updateSelectedCertificate.id,
            name: updateSelectedCertificate.name,
            certificateDate: `${splitedDate[2]}-${splitedDate[1]}-${splitedDate[0]}`,
            description: updateSelectedCertificate.description,
            achievementStatus: updateSelectedCertificate.achievementStatus
        }
        const response = await CertificateService.update(JSON.stringify(requestBody));
        if (response.status===200) {                      
            updateModalCloseEvent(false)
            setTimeout(()=>{
                window.location.reload();
            },1000)            
        }  
        // if (response.status===200) {  
        //     console.log(response);                       
        //     setOpenAddModal(false)
        //     ToastService.toastSuccess(response.data.message)
        //     setTimeout(()=>{
        //         window.location.reload();
        //     },2000)
            
        // }
        // else {
        //     console.log(response.data);
        //     if(response.data.errors !==undefined){
        //         const error = Object.keys(response.data.errors);
        //         console.log(error);
        //         ToastService.toastWarning(response.data.errors[error[0]][0]??response.data.message)
        //         return;
        //     }
        //     console.log(response.data);
        //     ToastService.toastWarning(response.data.message)
        // }
    }

    const handleDelete = async() => {
               console.log("metoda girdi");
        const response = await CertificateService.delete(updateSelectedCertificate.id);
        if (response.status===200) {  
            console.log(response);                      
            updateModalCloseEvent()
            setTimeout(()=>{
                window.location.reload();
            },1000)
        }
    }

    if (status === 200) {
        return (
            <div className='px-0 py-6'>

                <FlowbiteGenericTable colSize={4}
                    data={data}
                    setAddSelectedCertificate={setAddSelectedCertificate}
                    setOpenAddModal={setOpenAddModal}
                    setOpenUpdateModal={setOpenUpdateModal}
                    setOpenDeleteModal={setOpenDeleteModal}
                    setUpdateSelectedCertificate={setUpdateSelectedCertificate}
                    addButtonEvent={addButtonEvent}
                    updateButtonEvent={updateButtonEvent}
                    deleteButtonEvent={deleteButtonEvent}
                />

                <Modal show={openAddModal} onClose={() => addModalCloseEvent()} size="xl">
                    <Modal.Header>
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                            Add Certificate 
                        </div>
                    </Modal.Header>
                    <Modal.Body className='overflow-visible'>
                        <form onSubmit={handleAddSubmit} className="mt-1 mb-1 ">
                            <div className="grid gap-4 mb-4 grid-cols-6">
                                <div className="col-span-6">
                                    <TextInput
                                        label="Name"
                                        id="name"
                                        type="text"
                                        placeholder="Certificate Name"
                                        value={addSelectedCertificate.name}
                                        onChange={selectedAddValueChange}
                                        required
                                    />
                                </div>
                                <div className="col-span-4 md:col-span-2 cursor-pointer">
                                    <Datepicker
                                        language='tr-TR'
                                        minDate={new Date(1970,1,1)}
                                        value={addSelectedCertificate.certificateDate}
                                        onSelectedDateChanged={(e) => selectedAddValueChange(e, true)}
                                        required />
                                </div>
                                <div className="col-span-6">
                                    <Textarea
                                        label="Description"
                                        id="description"
                                        rows="4"
                                        placeholder="Description"
                                        value={addSelectedCertificate.description}
                                        onChange={selectedAddValueChange}
                                        required
                                    />
                                </div>
                                <div className="col-span-4">
                                    <Checkbox id="achievementStatus"
                                        checked={addSelectedCertificate.achievementStatus}
                                        onChange={selectedAddValueChange} />
                                    <Label htmlFor="achievementStatus">Achievement status of the certificate</Label>
                                </div>
                            </div>
                            <div className="flex justify-end">
                                <Button type="submit" size="md" className="text-white inline-flex items-center bg-palette-5 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-2.5 py-1.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                    <svg className="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd"></path>
                                    </svg>
                                    Add
                                </Button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
                <Modal show={openUpdateModal} onClose={() => updateModalCloseEvent()} size="xl">
                    <Modal.Header>
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                            Update
                        </div>
                    </Modal.Header>
                    <Modal.Body className='overflow-visible'>
                        <form onSubmit={handleUpdateSubmit} className="mt-1 mb-1 ">
                            <div className="grid gap-4 mb-4 grid-cols-6">
                                <div className="col-span-6">
                                    <TextInput
                                        label="Name"
                                        id="name"
                                        type="text"
                                        placeholder="Certificate Name"
                                        value={updateSelectedCertificate.name}
                                        onChange={selectedUpdateValueChange}
                                        required
                                    />
                                </div>
                                <div className="col-span-4 md:col-span-2 cursor-pointer">
                                    <Datepicker
                                        minDate={new Date(1970,1,1)}
                                        value={updateSelectedCertificate.certificateDate}
                                        onSelectedDateChanged={(e) => selectedUpdateValueChange(e, true)}
                                        required />
                                </div>
                                <div className="col-span-6">
                                    <Textarea
                                        label="Description"
                                        id="description"
                                        rows="4"
                                        placeholder="Description"
                                        value={updateSelectedCertificate.description}
                                        onChange={selectedUpdateValueChange}
                                        required
                                    />
                                </div>
                                <div className="col-span-4">
                                    <Checkbox id="achievementStatus"
                                        checked={updateSelectedCertificate.achievementStatus}
                                        onClick={selectedUpdateValueChange} />
                                    <Label htmlFor="achievementStatus">Achievement status of the certificate</Label>
                                </div>
                            </div>
                            <div className="flex justify-end">
                                <Button type="submit" size="md" className="text-white inline-flex items-center bg-palette-5 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-2.5 py-1.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                    <svg className="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd"></path>
                                    </svg>
                                    Update
                                </Button>
                            </div>
                        </form>
                    </Modal.Body>
                </Modal>
                <Modal show={openDeleteModal} onClose={() => setOpenDeleteModal(false)}>
                    <Modal.Header />
                    <Modal.Body>
                        <div className="text-center">
                            <svg
                                className="text-gray-400 dark:text-gray-500 w-11 h-11 mb-3.5 mx-auto"
                                aria-hidden="true"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fillRule="evenodd"
                                    d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                    clipRule="evenodd"
                                />
                            </svg>
                            <p className="mb-4 text-gray-500 dark:text-gray-300">
                                Are you sure you want to delete this certificate?
                            </p>
                            <div className="flex justify-center items-center space-x-4">
                                <Button
                                    color="light"
                                    onClick={() => setOpenDeleteModal(false)}
                                >
                                    No
                                </Button>
                                <Button
                                    color="failure"
                                    onClick={()=>handleDelete()}
                                >
                                    Yes
                                </Button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            </div>


            // const [updateFormData, setUpdateFormData] = useState({
            //     id: 0,
            //     name: '',
            //     certificateDate: '',
            //     description: '',
            //     achievementStatus: ''
            // });
            // const [addFormData, setAddFormData] = useState({
            //     name: '',
            //     certificateDate: '',
            //     description: '',
            //     achievementStatus: ''
            // });

            // useEffect(()=>{
            //     let certificates = CertificateService.getAll();
            //     if(certificates.status===200){
            //         setData(certificates);
            //         ToastService.toastSuccess(certificates.data.message)
            //     }
            //     else{
            //         ToastService.toastWarning(certificates.data.message)
            //     }
            // },[])

            // const handleChange = (e) => {
            //     const { name, value } = e.target;
            //     setFormData({ ...formData, [name]: value });
            // };


            // {  id: 1,name: 'C#',certificateDate: '08/11/1997',description: 'fgjhnfdcgtujhsxedyh',achievementStatus: true},
            //     {  id: 2,name: '.Net',certificateDate: '01/12/1997',description: 'gvfhkmlöjnfgvlkihf',achievementStatus: false},
            //     {  id: 3,name: 'React',certificateDate: '03/14/1997',description: 'xcgvhjxdg',achievementStatus: false},
            //     {  id: 4,name: 'React Native',certificateDate: '02/17/1997',description: 'gyklıtfyorplşuokrtfd',achievementStatus: true},
            //     {  id: 5,name: 'Vite',certificateDate: '03/21/1997',description: 'hıkjjlşçgfvythkömfvyk',achievementStatus: false},
            //     {  id: 6,name: 'Python',certificateDate: '03/24/1997',description: 'fgftcghjndcgt fvhnxd sfyhjhnfdcgtujhsxedyh',achievementStatus: false},
            //     {  id: 7,name: 'Java',certificateDate: '03/1/1997',description: 'nlişiKoojlşjhuılşçhnujjlçöh',achievementStatus: false},
            //     {  id: 8,name: 'Vue',certificateDate: '03/14/1994',description: 'uıotgyıkgfhlköghjkölgh',achievementStatus: true},
            //




            //  <GenericTable data={[{firstName:"Muhammet",lastName:"Şanverdi",phoneNumber:"3456345345",address:"dkfljgldf",salary:342341}]}/> 

            //     <div>
            //         {/* <!-- Start block --> */}
            //         <section className="bg-gray-50 dark:bg-gray-900 p-3 sm:p-5 antialiased">
            //             <div className="mx-auto max-w-screen-xl px-4 lg:px-12">
            //                 {/* <!-- Start coding here --> */}
            //                 <div className="bg-white dark:bg-gray-800 relative shadow-md sm:rounded-lg overflow-hidden">
            //                     <div className="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
            //                         <div className="w-full md:w-1/2">
            //                             <button type="button" onClick={() => setOpenAddModal(!openAddModal)} id="createProductModalButton" data-modal-target="createProductModal" data-modal-toggle="createProductModal" className="flex items-center justify-center text-white bg-palette-2 hover:bg-palette-3 focus:ring-4 focus:bg-palette-2 font-medium rounded-lg text-sm px-4 py-2 transition duration-250   dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            //                                 <svg className="h-3.5 w-3.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            //                                     <path clipRule="evenodd" fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            //                                 </svg>
            //                                 Add product
            //                             </button>
            //                         </div>
            //                         {/* <div className="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-start md:space-x-3 flex-shrink-0">
            //                             <button type="button" onClick={() => setOpenAddModal(!openAddModal)} id="createProductModalButton" data-modal-target="createProductModal" data-modal-toggle="createProductModal" className="flex items-center justify-center text-white bg-palette-2 hover:bg-palette-3 focus:ring-4 focus:bg-palette-2 font-medium rounded-lg text-sm px-4 py-2 transition duration-250   dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            //                                 <svg className="h-3.5 w-3.5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            //                                     <path clipRule="evenodd" fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            //                                 </svg>
            //                                 Add product
            //                             </button>

            //                         </div> */}
            //                     </div>
            //                     <div className="overflow-x-auto">
            //                         <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            //                             <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            //                                 <tr>
            //                                     <th scope="col" className="px-4 py-4">Product name</th>
            //                                     <th scope="col" className="px-4 py-3">Category</th>
            //                                     <th scope="col" className="px-4 py-3">Brand</th>
            //                                     <th scope="col" className="px-4 py-3">Description</th>
            //                                     <th scope="col" className="px-4 py-3">Price</th>
            //                                     <th scope="col" className="px-4 py-3">
            //                                         <span className="sr-only">Actions</span>
            //                                     </th>
            //                                 </tr>
            //                             </thead>
            //                             <tbody>
            //                                 <tr className="border-b dark:border-gray-700">
            //                                     <th scope="row" className="px-4 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white">PlayStation 5</th>
            //                                     <td className="px-4 py-3">Gaming/Console</td>
            //                                     <td className="px-4 py-3">Sony</td>
            //                                     <td className="px-4 py-3 max-w-[12rem] truncate">What is a product description? A product description describes a product.</td>
            //                                     <td className="px-4 py-3">$799</td>
            //                                     <td className="px-4 py-3 flex items-center justify-end">
            //                                         <Dropdown label={
            //                                             <svg className="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            //                                                 <path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z" />
            //                                             </svg>
            //                                         } inline>
            //                                             <Dropdown.Header>
            //                                                 Actions
            //                                             </Dropdown.Header>
            //                                             <Dropdown.Item onClick={() => setOpenUpdateModal(true)}>
            //                                                 <svg className="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            //                                                     <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
            //                                                     <path fillRule="evenodd" clipRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" />
            //                                                 </svg>
            //                                                 Edit
            //                                             </Dropdown.Item>
            //                                             <Dropdown.Item onClick={() => setOpenDeleteModal(true)} className="text-red-500">
            //                                                 <svg className="w-4 h-4 mr-2" viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            //                                                     <path fillRule="evenodd" clipRule="evenodd" fill="currentColor" d="M6.09922 0.300781C5.93212 0.30087 5.76835 0.347476 5.62625 0.435378C5.48414 0.523281 5.36931 0.649009 5.29462 0.798481L4.64302 2.10078H1.59922C1.36052 2.10078 1.13161 2.1956 0.962823 2.36439C0.79404 2.53317 0.699219 2.76209 0.699219 3.00078C0.699219 3.23948 0.79404 3.46839 0.962823 3.63718C1.13161 3.80596 1.36052 3.90078 1.59922 3.90078V12.9008C1.59922 13.3782 1.78886 13.836 2.12643 14.1736C2.46399 14.5111 2.92183 14.7008 3.39922 14.7008H10.5992C11.0766 14.7008 11.5344 14.5111 11.872 14.1736C12.2096 13.836 12.3992 13.3782 12.3992 12.9008V3.90078C12.6379 3.90078 12.8668 3.80596 13.0356 3.63718C13.2044 3.46839 13.2992 3.23948 13.2992 3.00078C13.2992 2.76209 13.2044 2.53317 13.0356 2.36439C12.8668 2.1956 12.6379 2.10078 12.3992 2.10078H9.35542L8.70382 0.798481C8.62913 0.649009 8.5143 0.523281 8.37219 0.435378C8.23009 0.347476 8.06631 0.30087 7.89922 0.300781H6.09922ZM4.29922 5.70078C4.29922 5.46209 4.39404 5.23317 4.56282 5.06439C4.73161 4.8956 4.96052 4.80078 5.19922 4.80078C5.43791 4.80078 5.66683 4.8956 5.83561 5.06439C6.0044 5.23317 6.09922 5.46209 6.09922 5.70078V11.1008C6.09922 11.3395 6.0044 11.5684 5.83561 11.7372C5.66683 11.906 5.43791 12.0008 5.19922 12.0008C4.96052 12.0008 4.73161 11.906 4.56282 11.7372C4.39404 11.5684 4.29922 11.3395 4.29922 11.1008V5.70078ZM8.79922 4.80078C8.56052 4.80078 8.33161 4.8956 8.16282 5.06439C7.99404 5.23317 7.89922 5.46209 7.89922 5.70078V11.1008C7.89922 11.3395 7.99404 11.5684 8.16282 11.7372C8.33161 11.906 8.56052 12.0008 8.79922 12.0008C9.03791 12.0008 9.26683 11.906 9.43561 11.7372C9.6044 11.5684 9.69922 11.3395 9.69922 11.1008V5.70078C9.69922 5.46209 9.6044 5.23317 9.43561 5.06439C9.26683 4.8956 9.03791 4.80078 8.79922 4.80078Z" />
            //                                                 </svg>
            //                                                 Delete
            //                                             </Dropdown.Item>
            //                                         </Dropdown>


            //                                     </td>
            //                                 </tr>

            //                             </tbody>
            //                         </table>
            //                     </div>
            //                     <nav className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-3 md:space-y-0 p-4" aria-label="Table navigation">
            //                         <span className="text-sm font-normal text-gray-500 dark:text-gray-400">
            //                             Showing
            //                             <span className="font-semibold text-gray-900 dark:text-white">1-10</span>
            //                             of
            //                             <span className="font-semibold text-gray-900 dark:text-white">1000</span>
            //                         </span>
            //                         <ul className="inline-flex items-stretch -space-x-px">
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
            //                                     <span className="sr-only">Previous</span>
            //                                     <svg className="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            //                                         <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            //                                     </svg>
            //                                 </a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">1</a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">2</a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" aria-current="page" className="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-primary-300 hover:bg-primary-100 hover:text-primary-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white">3</a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">...</a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">100</a>
            //                             </li>
            //                             <li>
            //                                 <a href="#" className="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
            //                                     <span className="sr-only">Next</span>
            //                                     <svg className="w-5 h-5" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            //                                         <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
            //                                     </svg>
            //                                 </a>
            //                             </li>
            //                         </ul>
            //                     </nav>
            //                 </div>
            //             </div>
            //         </section>
            //         {/* <!-- End block --> */}
            //         {/* <!-- Create modal --> */}
            //         <Modal show={openAddModal} onClose={() => setOpenAddModal(false)}>
            //             <Modal.Header>
            //                 <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            //                     Create New Product
            //                 </h3>
            //             </Modal.Header>
            //             <Modal.Body>
            //                 <form onSubmit={handleUpdateSubmit} className="p-4 md:p-5">
            //                     <div className="grid gap-4 mb-4 grid-cols-2">
            //                         <div className="col-span-2">
            //                             <TextInput
            //                                 label="Name"
            //                                 id="name"
            //                                 type="text"
            //                                 placeholder="Type product name"
            //                                 required
            //                             />
            //                         </div>
            //                         <div className="col-span-2 sm:col-span-1">
            //                             <TextInput
            //                                 label="Price"
            //                                 id="price"
            //                                 type="number"
            //                                 placeholder="$2999"
            //                                 required
            //                             />
            //                         </div>
            //                         <div className="col-span-2 sm:col-span-1">
            //                             <Select
            //                                 label="Category"
            //                                 id="category"
            //                             >
            //                                 <option>Select category</option>
            //                                 <option value="TV">TV/Monitors</option>
            //                                 <option value="PC">PC</option>
            //                                 <option value="GA">Gaming/Console</option>
            //                                 <option value="PH">Phones</option>
            //                             </Select>
            //                         </div>
            //                         <div className="col-span-2">
            //                             <Textarea
            //                                 label="Product Description"
            //                                 id="description"
            //                                 rows="4"
            //                                 placeholder="Write product description here"
            //                             />
            //                         </div>
            //                     </div>
            //                     <div className="flex justify-end">
            //                         <Button type="submit" size="md" className="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-2.5 py-1.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            //                             <svg className="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            //                                 <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd"></path>
            //                             </svg>
            //                             Add new product
            //                         </Button>
            //                     </div>
            //                 </form>
            //             </Modal.Body>
            //         </Modal>

            //         {/* <!-- Update modal --> */}
            //         <Modal show={openUpdateModal} onClose={() => setOpenUpdateModal(false)}>
            //             <Modal.Header>
            //                 <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Update Product</h3>
            //             </Modal.Header>
            //             <Modal.Body>
            //                 <form onSubmit={handleUpdateSubmit}>
            //                     <div className="grid gap-4 mb-4 sm:grid-cols-2">
            //                         <div>
            //                             <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Name</label>
            //                             <input
            //                                 type="text"
            //                                 name="name"
            //                                 id="name"
            //                                 value={updateFormData.name}
            //                                 onChange={handleChange}
            //                                 className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            //                                 placeholder="Ex. Apple iMac 27&ldquo;"
            //                             />
            //                         </div>
            //                         <div>
            //                             <label htmlFor="brand" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Brand</label>
            //                             <input
            //                                 type="text"
            //                                 name="brand"
            //                                 id="brand"
            //                                 value={updateFormData.brand}
            //                                 onChange={handleChange}
            //                                 className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            //                                 placeholder="Ex. Apple"
            //                             />
            //                         </div>
            //                         <div>
            //                             <label htmlFor="price" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Price</label>
            //                             <input
            //                                 type="number"
            //                                 name="price"
            //                                 id="price"
            //                                 value={updateFormData.price}
            //                                 onChange={handleChange}
            //                                 className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            //                                 placeholder="$299"
            //                             />
            //                         </div>
            //                         <div>
            //                             <label htmlFor="category" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category</label>
            //                             <select
            //                                 id="category"
            //                                 name="category"
            //                                 value={updateFormData.category}
            //                                 onChange={handleChange}
            //                                 className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            //                             >
            //                                 <option value="default">Electronics</option>
            //                                 <option value="TV">TV/Monitors</option>
            //                                 <option value="PC">PC</option>
            //                                 <option value="GA">Gaming/Console</option>
            //                                 <option value="PH">Phones</option>
            //                             </select>
            //                         </div>
            //                         <div className="sm:col-span-2">
            //                             <label htmlFor="description" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
            //                             <textarea
            //                                 id="description"
            //                                 name="description"
            //                                 rows="5"
            //                                 value={updateFormData.description}
            //                                 onChange={handleChange}
            //                                 className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            //                                 placeholder="Write a description..."
            //                             />
            //                         </div>
            //                     </div>
            //                     <div className="flex items-center space-x-4">
            //                         <Button type="submit" className="text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
            //                             Update product
            //                         </Button>
            //                         <Button
            //                             type="button"
            //                             color="failure"
            //                             className="text-red-600 inline-flex items-center hover:text-white border border-red-600 hover:bg-red-600 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:border-red-500 dark:text-red-500 dark:hover:text-white dark:hover:bg-red-600 dark:focus:ring-red-900"
            //                         >
            //                             <svg className="mr-1 -ml-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            //                                 <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
            //                             </svg>
            //                             Delete
            //                         </Button>
            //                     </div>
            //                 </form>
            //             </Modal.Body>
            //         </Modal>
            //         {/* <!-- Delete modal --> */}
            //         <Modal show={openDeleteModal} onClose={() => setOpenDeleteModal(false)}>
            //   <Modal.Header/>    
            //   <Modal.Body>
            //     <div className="text-center">
            //       <svg
            //         className="text-gray-400 dark:text-gray-500 w-11 h-11 mb-3.5 mx-auto"
            //         aria-hidden="true"
            //         fill="currentColor"
            //         viewBox="0 0 20 20"
            //         xmlns="http://www.w3.org/2000/svg"
            //       >
            //         <path
            //           fillRule="evenodd"
            //           d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
            //           clipRule="evenodd"
            //         />
            //       </svg>
            //       <p className="mb-4 text-gray-500 dark:text-gray-300">
            //         Are you sure you want to delete this item?
            //       </p>
            //       <div className="flex justify-center items-center space-x-4">
            //         <Button
            //           color="light"
            //           onClick={() => setOpenDeleteModal(false)}
            //         >
            //           No, cancel
            //         </Button>
            //         <Button
            //           color="failure"
            //           onClick={handleDelete}
            //         >
            //           Yes, I'm sure
            //         </Button>
            //       </div>
            //     </div>
            //   </Modal.Body>
            // </Modal>
            //     </div>

        )
    }

}

export default BuildingTable


