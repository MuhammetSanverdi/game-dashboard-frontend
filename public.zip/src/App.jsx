import { useState } from 'react'
import './App.css'
import Login from './pages/Login'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p> */}

      <Login/>
    </>
  )
}

export default App
